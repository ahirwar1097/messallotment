from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from PIL import Image


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    image = models.ImageField(default='default.jpg', upload_to='profile_pics')
    
    def __str__(self):
        return f'{self.user.username} Profile'

    def save(self, *args, **kwargs):
        super(Profile, self).save(*args, **kwargs)
        img = Image.open(self.image.path)
        if img.height > 300 or img.width > 300:
            output_size = (300, 300)
            img.thumbnail(output_size)
            img.save(self.image.path)


class UpdateDetails(models.Model):
    GENDER = [
       ('MALE', 'MALE'),
       ('FEMALE', 'FEMALE')
    ]
    COURSE = [
        ('B.Tech', 'B.Tech'),
        ('M.Tech', 'M.Tech'),
        ('MCA', 'MCA'),
        ('M.Sc', 'M.Sc'),
        ('MBA', 'MBA')
    ]
    DEPARTMENT = [
        ('Computer Science And Engineering', 'Computer Science And Engineering'),
        ('Mathematical And Computational Sciences', 'Mathematical And Computational Sciences'),
        ('Information Technology', 'Information Technology'),
        ('Chemical Engineering', 'Chemical Engineering'),
        ('Civil Engineering', 'Civil Engineering'),
        ('Mechanical Engineering', 'Mechanical Engineering'),
        ('School Of Management', 'School Of Management')
    ]
    HOSTEL = [
        ('1st Block', '1st Block'),
        ('2nd Block', '2nd Block'),
        ('3rd Block', '3rd Block'),
        ('4th Block', '4th Block'),
        ('5th Block', '5th Block'),
        ('7th Block', '7th Block'),
        ('8th Block', '8th Block'),
        ('Mega Block', 'Mega Block'),
        ('PG Block', 'PG Block'),
        ('Ganga', 'Ganga'),
        ('Yamuna', 'Yamuna'),
        ('Sarswati', 'Sarswati'),
        ('Netravathi', 'Netravati')
    ]
    stu_reg_no = models.CharField(max_length=15, primary_key=True)
    stu_name = models.CharField(max_length=50, null=False)
    stu_gender = models.CharField(max_length=6, choices=GENDER,default='MALE')
    stu_course = models.CharField(max_length=50, choices=COURSE,default='B.Tech')
    stu_dept = models.CharField(max_length=50, choices=DEPARTMENT,default='Computer Science And Engineering')
    stu_hostel_block = models.CharField(max_length=50, choices=HOSTEL,default='8th Block')
    stu_room_no = models.IntegerField(null=False)
    stu_email = models.EmailField(max_length=50, null=False)
    stu_contact = models.IntegerField(null=False)
    stu_mess_roll_no = models.CharField(max_length=10, null=False)
    last_updated= models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.stu_reg_no
