from django.shortcuts import render,redirect,HttpResponse
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from .forms import UpdateDetailsForm, UserRegisterForm, UserUpdateForm,ProfileUpdateForm
from .models import UpdateDetails
from django.contrib import messages
from mess.models import MessModel,FeeDetailsModel,MessAllotModel
from django.contrib.auth.models import User, auth


@login_required
def profile(request):
	if request.method == 'POST':
		p_form = ProfileUpdateForm(request.POST, request.FILES, instance=request.user.profile)

		if p_form.is_valid():
			p_form.save()
			messages.success(request, f'Your account has been updated!')
			return redirect('profile')

	else:
		p_form = ProfileUpdateForm(instance=request.user.profile)

	context = {
		'p_form': p_form
	}
	return render(request, 'user/profile.html',context)


def register(request, *args, **kwargs):
	if request.method == 'POST':
		form = UserRegisterForm(request.POST)
		if form.is_valid():
			form.save()
			username = form.cleaned_data.get('username')
			messages.success(request, f'Your account has been created! You are now able to login')
			return redirect('mess')
	else:
		form = UserRegisterForm()
	return render(request, 'user/register.html', {'form': form})


# def login(request):
# 	if request.method == 'POST':
# 		username = request.POST['username']
# 		password = request.POST['password']
# 		user = auth.authenticate(username=username, password=password)
#
# 		if user is not None:
# 			auth.login(request, user)
# 			return redirect('/')
# 		# messages.info(request, 'logged in')
# 		else:
# 			messages.info(request, 'bad credentials')
# 	else:
# 		return render(request, 'login.html')
#
#
#
# def logout(request):
#     auth.logout(request)
#     return redirect('/')


@login_required
def UpdateDetailsView(request):
	if request.method == 'POST':
		form = UpdateDetailsForm(request.POST)
		if form.is_valid():
			current_user = request.user
			stu_reg_no = current_user.username
			stu_name = current_user.get_full_name()
			stu_gender = request.POST["stu_gender"]
			stu_course = request.POST["stu_course"]
			stu_dept = request.POST["stu_dept"]
			stu_hostel_block = request.POST["stu_hostel_block"]
			stu_room_no = request.POST["stu_room_no"]
			stu_email = current_user.email
			stu_contact = request.POST["stu_contact"]
			stu_mess_roll_no = request.POST["stu_mess_roll_no"]
			saviour = UpdateDetails(stu_reg_no=stu_reg_no, stu_name = stu_name, stu_gender = stu_gender, stu_course = stu_course, stu_dept = stu_dept, stu_hostel_block = stu_hostel_block, stu_room_no = stu_room_no, stu_email = stu_email, stu_contact= stu_contact, stu_mess_roll_no = stu_mess_roll_no)
			saviour.save()
			messages.success(request, f'profile updated successfully!')
			return render(request, 'mess/boot.html')
	else:
		form = UpdateDetailsForm()
	return render(request, 'user/details.html', {'form': form})


def profile(request):
	stu_id = UpdateDetails.objects.get(stu_reg_no=request.user)
	mess_id = MessAllotModel.objects.get(allot_reg_no=request.user)
	name = MessModel.objects.get(mess_id=mess_id.allot_mess_id)
	fee = FeeDetailsModel.objects.get(stu_reg_no=request.user)
	return render(request, 'user/profile.html', {'stu_id': stu_id, 'name': name, 'fee': fee})