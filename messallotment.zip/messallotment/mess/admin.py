from django.contrib import admin
from .models import MessModel, ContactModel, FeeDetailsModel, MessAllotModel

admin.site.register(MessModel)
admin.site.register(ContactModel)
admin.site.register(FeeDetailsModel)
admin.site.register(MessAllotModel)
