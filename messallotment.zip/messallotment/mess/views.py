from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User, auth
from django.contrib import messages
from .models import MessModel, ContactModel, FeeDetailsModel, MessAllotModel
from user.models import UpdateDetails


def home(request):
	return render(request, 'mess/boot.html')


def about(request):
	return render(request, 'mess/about.html')


def feedback(request):
	feed = ContactModel.objects.all();
	return render(request, 'mess/feedback.html', {'feed': feed})


def contactus(request):
	if request.method == 'POST':
		name = request.POST['name']
		email = request.POST['email']
		message = request.POST['message']
		add_obj = ContactModel(
			student_name=name,
			student_email=email,
			Feedback=message
			)
		add_obj.save()
		return redirect('/')
	else:
		return render(request, 'mess/contact.html')


def mess_seats(request):
	mess = MessModel.objects.all()
	return render(request, 'mess/messseats.html', {'mess': mess})


def mess_details(request):
	current_user = request.user
	stu = UpdateDetails.objects.get(stu_reg_no=current_user)
	mess = MessModel.objects.filter(mess_boys=stu.stu_gender)
	return render(request, 'mess/allot.html', {'mess': mess})


def allot_details(request):
	if request.method == 'POST':
		mes_id = request.POST['Messes']
		current_user = request.user
		fee_uid = FeeDetailsModel.objects.get(stu_reg_no=current_user)
		mes_obj = MessModel.objects.get(mess_id=mes_id)
		mess_count = mes_obj.remaining_seats
		if MessAllotModel.objects.filter(allot_reg_no=current_user).exists():
			messages.info(request, 'Mess already alloted')
			return redirect('/')
		elif fee_uid.fee_status is True:
			if int(mess_count) <= 0:
				messages.info(request, 'Sorry ! All seats filled. Please select another mess!')
				return redirect('mess/allot.html')
			else:
				add_mess_obj = MessAllotModel(
					allot_reg_no=current_user,
					allot_mess_id=mes_obj,
					allot_mess=True)
				add_mess_obj.save()
				count = int(mess_count) - 1
				mes_obj.remaining_seats = count
				mes_obj.save(update_fields=['remaining_seats'])
				messages.info(request, 'mess alloted successfully')
				return redirect('/')
		else:
			messages.info(request, 'Fee Not Paid!!!!!')
			return redirect('/')
		return HttpResponse("welcome")
	else:
		return render(request, 'mess/allot.html')
