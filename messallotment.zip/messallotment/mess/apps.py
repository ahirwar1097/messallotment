from django.apps import AppConfig


class MessConfig(AppConfig):
    name = 'mess'
